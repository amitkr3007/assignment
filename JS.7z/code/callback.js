/**
 * Created by sagakulk on 6/8/2016.
 */


function foo(bar){
    bar();
}

foo(function(){
    console.log("Call me back!!!");
});