package com.singleton;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {
   public static void main(String[] args) {
      ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
//Singleton
      System.out.println("Singleton");
      HelloWorld objA = (HelloWorld) context.getBean("helloWorld");

      objA.setMessage("I'm object A");
      objA.getMessage();

      HelloWorld objB = (HelloWorld) context.getBean("helloWorld");
      objB.getMessage();
      
 //Prototype
   System.out.println("ProtoType");   
      HelloWorld objC = (HelloWorld) context.getBean("worldhello");

      objA.setMessage("I'm object C");
      objA.getMessage();

      HelloWorld objD = (HelloWorld) context.getBean("worldhello");
      objD.getMessage();
   }
}