/**
 * Created by sagakulk on 6/9/2016.
 */

function sendRequest(){
    var XHR = getXHR()
    if(XHR){
        XHR.open("GET","data/data.json",true);
        XHR.onreadystatechange = function(){handleResponse(XHR);}
        XHR.send();
    }
}

function getXHR(){
    return new XMLHttpRequest();
}

function handleResponse(XHR){
    if(XHR.readyState==4){
        //console.log("data received... ",XHR.responseText);
        var table = document.getElementById('person');
        var persons = JSON.parse(XHR.responseText);

        for(var i=0;i<persons.length;i++){
            var row =table.insertRow(i);
            var cell1 = row.insertCell(0);
            var cell2 = row.insertCell(1);
            cell1.innerHTML=persons[i].name;
            cell2.innerHTML=persons[i].city;
        }

    }
}










