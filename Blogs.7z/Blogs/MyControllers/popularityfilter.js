/**
 * Created by akuma373 on 6/15/2016.
 */
return function(value){
    //noinspection JSAnnotator
    if(value<50){
        return "not popular";
    }
    else {
        return "popular";
    }
    }
}