/**
 * Created by sagakulk on 6/9/2016.
 */

var p = new Object();
p.name = 'Sachin';
p.age = 43;
p.print = function(){
    console.log(this.name, this.age);
}

p.print();

/******************************************/

var p = {
        name:"Sagar",
        age: 41,
        hobbies:['music','racket sport'],
        luckyNumbers:[3,9,5,11],
        address:{
            addressLine:'G-16 Swapnashilpa Apartments',
            city:'Pune'
        },
        familyMembers:[
            {
                name:'Mrudula',
                relation:'spouce'
            },
            {
                name:'Renu',
                relation:'daughter'
            }
        ],
        getName: function(){
            return this.name;
        }
}

console.log(p.getName(), p.address.city, p.familyMembers[1].name);

/********************************************************************/

var person = function(name,age){
    return {
        name:name,
        age:age
    }
}

var p= person('Srinath',23);


console.log(p);

/*****************************************************/
var person = function(name,age){
        this.name=name,
        this.age=age
    }
var p= new person('Sandeep',23);
console.log(p.name, p.age);















