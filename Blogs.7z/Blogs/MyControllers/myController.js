/**
 * Created by akuma373 on 13-Jun-16.
 */


var blogController = helloApp.controller('blogController', function ($scope) {
    $scope.sortorder='';
    $scope.blogs = [
        {
            title: "My experiments with Truth ",
            author: "Mahatma M.K.Gandhi",
            year: "1927",
            description: "The Story of My Experiments with Truth is the autobiography of Mohandas K. Gandhi, covering his life from early childhood through to 1921. It was written in weekly instalments and published in his journal Navjivan from 1925 to 1929",
            vote:"50"
        },
        {
            title: "A passage to India",
            author: "E. M. Forster",
            year: "1869",
            description: "A Passage to India is a novel by English author E. M. Forster set against the backdrop of the British Raj and the Indian independence movement in the 1920s.It was selected as one of the 100 great works of 20th century English literature",
            vote:"20"
        },
        {
            title: "War and peace",
            author: "Leo Tolstoy",
            year: "1887",
            description:"War and Peace is a novel by the Russian author Leo Tolstoy. It is regarded as one of the central works of world literature. War and Peace and Tolstoy's other major  work, Anna Karenina, are considered Tolstoy's finest literary achievements .",
            vote:"30"
        },
        {
            title: "Geetanjali",
            author: "Rabindra Nath Tagore",
            year: "1910",
            description:"Gitanjali is a collection of poems by the Bengali poet Rabindranath Tagore. The original Bengali collection of 157 poems was published on August 14, 1910.",
            vote:"35"
        }
    ]
});